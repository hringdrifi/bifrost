G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-09-04T23:55:07+09:00*
G04 #@! TF.ProjectId,bifrost_right_plate,62696672-6f73-4745-9f72-696768745f70,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-09-04 23:55:07*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10O,2.600000X2.200000*%
%ADD11C,2.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X212725500Y-126206250D03*
G04 #@! TD*
D11*
G04 #@! TO.C,REF\u002A\u002A*
X69850500Y-130869949D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X86521266Y-64326109D03*
G04 #@! TD*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X212725500Y-50006250D03*
G04 #@! TD*
M02*
