G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-08-17T01:26:35+09:00*
G04 #@! TF.ProjectId,bifrost_left_thumb,62696672-6f73-4745-9f6c-6566745f7468,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-17 01:26:35*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10R,0.700000X0.700000*%
%ADD11RotRect,0.700000X0.700000X186.179000*%
%ADD12RotRect,0.700000X0.700000X173.821000*%
%ADD13C,5.250000*%
%ADD14C,3.600000*%
%ADD15RoundRect,0.300000X-0.200000X0.200000X-0.200000X-0.200000X0.200000X-0.200000X0.200000X0.200000X0*%
%ADD16C,1.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D2*
X100833750Y-65256250D03*
X100833750Y-64156250D03*
X99003750Y-64156250D03*
X99003750Y-65256250D03*
G04 #@! TD*
D11*
G04 #@! TO.C,D1*
X81999033Y-66097952D03*
X81880635Y-65004343D03*
X80061267Y-65201314D03*
X80179665Y-66294923D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D3*
X119650391Y-66445419D03*
X119768789Y-65351811D03*
X117949421Y-65154839D03*
X117831023Y-66248447D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW3*
X118660983Y-60579849D03*
D14*
X123541306Y-56380748D03*
X116694989Y-54583403D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW1*
X79777206Y-60580041D03*
D14*
X83645759Y-55433752D03*
X76573409Y-55143296D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW2*
X99218750Y-59531250D03*
D14*
X103618750Y-54831250D03*
X96618750Y-53781250D03*
G04 #@! TD*
D15*
G04 #@! TO.C,J1*
X96043750Y-50403125D03*
D16*
X97313750Y-50403126D03*
X98583750Y-50403125D03*
X99853750Y-50403125D03*
X101123750Y-50403126D03*
X102393749Y-50403125D03*
G04 #@! TD*
M02*
